Insert into defaults values ('PRESCRIPTIONALERT','Prescription Alert','Please enter Numbers of Days and select Timings for prescribed medicines where applicable','Text','','','','');

update `db_version` set `version` = '1.0.4';