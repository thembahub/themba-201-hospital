<?php if(!$this->input->post('submit')) { ?>
  <meta http-equiv="refresh" content="300">
<?php } ?>
