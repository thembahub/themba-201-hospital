<?php
$config['protocol'] = "smtp";
$config['smtp_host'] = "localhost";
$config['smtp_port'] = "25";
$config['smtp_user'] = ""; 
$config['smtp_pass'] = "";
$config['charset'] = "utf-8";
$config['mailtype'] = "html";
$config['newline'] = "\r\n";
?>